"""Schema loader and utilities."""
import json
from typing import Dict, Any, List
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class SchemaLoader:
    """Load and manage database schema information."""

    def __init__(self, schema_dict: Dict[str, Any]):
        """
        Initialize schema loader.

        Args:
            schema_dict: Dictionary containing table and column information.
        """
        self.schema = schema_dict
        self.tables = list(schema_dict.keys())

    @classmethod
    def from_db_adapter(cls, db_adapter):
        """Create SchemaLoader from a DatabaseAdapter instance."""
        schema = db_adapter.get_schema()
        return cls(schema)

    @classmethod
    def from_json_file(cls, file_path: str):
        """Load schema from a JSON file."""
        with open(file_path, 'r') as f:
            schema = json.load(f)
        return cls(schema)

    def save_to_json(self, file_path: str) -> None:
        """Save schema to a JSON file."""
        with open(file_path, 'w') as f:
            json.dump(self.schema, f, indent=2)
        logger.info(f"Schema saved to {file_path}")

    def get_table_columns(self, table_name: str) -> List[str]:
        """Get column names for a table."""
        if table_name not in self.schema:
            return []
        return [col['name'] for col in self.schema[table_name]['columns']]

    def get_table_description(self, table_name: str) -> str:
        """Get a human-readable description of a table."""
        if table_name not in self.schema:
            return ""
        
        columns = self.schema[table_name]['columns']
        column_desc = ", ".join([f"{col['name']} ({col['type']})" for col in columns])
        return f"{table_name}: {column_desc}"

    def get_schema_context(self) -> str:
        """Get schema context for LLM prompt."""
        descriptions = []
        for table_name in self.tables:
            descriptions.append(self.get_table_description(table_name))
        return "\n".join(descriptions)

    def get_allowlist(self) -> Dict[str, List[str]]:
        """Get allowlist of tables and columns for SQL execution."""
        return {
            table: self.get_table_columns(table)
            for table in self.tables
        }

    def validate_table(self, table_name: str) -> bool:
        """Check if a table exists in the schema."""
        return table_name in self.schema

    def validate_column(self, table_name: str, column_name: str) -> bool:
        """Check if a column exists in a table."""
        if table_name not in self.schema:
            return False
        columns = self.get_table_columns(table_name)
        return column_name in columns
