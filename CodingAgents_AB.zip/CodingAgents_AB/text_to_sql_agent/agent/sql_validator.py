"""SQL validation and security checks."""
import re
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)


class SQLValidator:
    """Validate SQL queries for read-only safety."""

    # Forbidden SQL keywords for write operations and unsafe actions
    FORBIDDEN_KEYWORDS = {
        'INSERT', 'UPDATE', 'DELETE', 'DROP', 'ALTER', 'CREATE',
        'REPLACE', 'TRUNCATE', 'ATTACH', 'DETACH', 'VACUUM',
        'PRAGMA', 'LOAD', 'EXECUTE', 'EXEC', 'GRANT', 'REVOKE'
    }

    # Allowed keywords for read-only operations
    ALLOWED_KEYWORDS = {
        'SELECT', 'FROM', 'WHERE', 'JOIN', 'LEFT', 'RIGHT', 'INNER',
        'OUTER', 'CROSS', 'ON', 'GROUP', 'BY', 'HAVING', 'ORDER',
        'LIMIT', 'OFFSET', 'DISTINCT', 'UNION', 'ALL', 'AND', 'OR',
        'NOT', 'IN', 'BETWEEN', 'LIKE', 'IS', 'NULL', 'AS', 'WITH',
        'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'SUM', 'AVG', 'COUNT',
        'MIN', 'MAX', 'CAST', 'COALESCE', 'IFNULL', 'DATE', 'DATETIME',
        'STRFTIME', 'SUBSTR', 'ROUND', 'ABS'
    }

    def __init__(self, schema_allowlist: dict = None):
        """
        Initialize SQL validator.

        Args:
            schema_allowlist: Dictionary of allowed tables and columns.
        """
        self.schema_allowlist = schema_allowlist or {}

    def validate(self, sql_query: str) -> Tuple[bool, str]:
        """
        Validate SQL query for safety.

        Args:
            sql_query: SQL query to validate.

        Returns:
            Tuple of (is_valid, error_message).
        """
        sql_query = sql_query.strip()

        # Check 1: Empty query
        if not sql_query:
            return False, "Query is empty"

        # Check 2: Query must start with SELECT
        if not sql_query.upper().startswith('SELECT') and not sql_query.upper().startswith('WITH'):
            return False, "Query must be a SELECT or WITH statement (read-only)"

        # Check 3: No forbidden keywords
        sql_upper = sql_query.upper()
        for keyword in self.FORBIDDEN_KEYWORDS:
            # Use word boundary matching to avoid false positives
            if re.search(rf'\b{keyword}\b', sql_upper):
                return False, f"Forbidden keyword found: {keyword}"

        # Check 4: Check for comment injections
        if '--' in sql_query or '/*' in sql_query:
            return False, "SQL comments are not allowed"

        # Check 5: Validate tables and columns if allowlist provided
        if self.schema_allowlist:
            is_valid, error_msg = self._validate_schema_access(sql_query)
            if not is_valid:
                return False, error_msg

        logger.info("SQL query passed validation")
        return True, ""

    def _validate_schema_access(self, sql_query: str) -> Tuple[bool, str]:
        """
        Validate that query only accesses allowed tables and columns.

        Args:
            sql_query: SQL query to validate.

        Returns:
            Tuple of (is_valid, error_message).
        """
        # Extract table names from FROM and JOIN clauses
        from_match = re.findall(r'\bFROM\s+(\w+)', sql_query, re.IGNORECASE)
        join_match = re.findall(r'\bJOIN\s+(\w+)', sql_query, re.IGNORECASE)
        
        referenced_tables = set(from_match + join_match)
        allowed_tables = set(self.schema_allowlist.keys())

        # Check if all referenced tables are allowed
        for table in referenced_tables:
            if table.upper() not in [t.upper() for t in allowed_tables]:
                return False, f"Table not in schema: {table}"

        logger.info(f"Schema validation passed for tables: {referenced_tables}")
        return True, ""

    @staticmethod
    def sanitize_query(sql_query: str) -> str:
        """
        Sanitize SQL query for safe execution.

        Args:
            sql_query: SQL query to sanitize.

        Returns:
            Sanitized SQL query.
        """
        # Remove leading/trailing whitespace and comments
        query = sql_query.strip()
        
        # Remove SQL comments
        query = re.sub(r'--.*$', '', query, flags=re.MULTILINE)
        query = re.sub(r'/\*.*?\*/', '', query, flags=re.DOTALL)
        
        # Normalize whitespace
        query = ' '.join(query.split())
        
        return query

    @staticmethod
    def extract_tables(sql_query: str) -> List[str]:
        """
        Extract table names from SQL query.

        Args:
            sql_query: SQL query.

        Returns:
            List of table names.
        """
        from_match = re.findall(r'\bFROM\s+(\w+)', sql_query, re.IGNORECASE)
        join_match = re.findall(r'\bJOIN\s+(\w+)', sql_query, re.IGNORECASE)
        return list(set(from_match + join_match))

    @staticmethod
    def extract_columns(sql_query: str) -> List[str]:
        """
        Extract column names from SELECT clause.

        Args:
            sql_query: SQL query.

        Returns:
            List of column names.
        """
        # Find the SELECT clause
        select_match = re.search(r'SELECT\s+(.*?)\s+FROM', sql_query, re.IGNORECASE | re.DOTALL)
        if not select_match:
            return []
        
        select_clause = select_match.group(1)
        # Split by comma and extract column names
        columns = re.findall(r'(\w+)', select_clause)
        return columns
