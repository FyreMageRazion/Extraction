"""OpenAI LLM interface for SQL generation."""
import os
import logging
from typing import Optional
from openai import OpenAI

logger = logging.getLogger(__name__)


class LLMInterface:
    """Interface to OpenAI for SQL generation and NLP tasks."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini", temperature: float = 0.0):
        """
        Initialize LLM interface.

        Args:
            api_key: OpenAI API key. If None, read from OPENAI_API_KEY environment variable.
            model: Model name to use (default: gpt-4o-mini for cost efficiency).
            temperature: Temperature for LLM responses (0.0 = deterministic).
        """
        if api_key is None:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY not set in environment or passed as argument")
        
        self.api_key = api_key
        self.model = model
        self.temperature = temperature
        self.client = OpenAI(api_key=api_key)
        logger.info(f"LLM Interface initialized with model: {model}")

    def generate_sql(self, user_query: str, schema_context: str, examples: str = "") -> str:
        """
        Generate SQL from a natural language query.

        Args:
            user_query: Natural language user query.
            schema_context: Database schema description.
            examples: Optional SQL examples for few-shot learning.

        Returns:
            Generated SQL query.
        """
        prompt = self._build_sql_prompt(user_query, schema_context, examples)
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert SQL query generator. Generate only valid, read-only SELECT SQL statements. Do not include explanations, only the SQL query."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=self.temperature,
                max_tokens=1000,
            )
            
            sql_query = response.choices[0].message.content.strip()
            logger.info(f"Generated SQL: {sql_query[:100]}...")
            return sql_query
        except Exception as e:
            logger.error(f"Failed to generate SQL: {e}")
            raise RuntimeError(f"SQL generation failed: {e}")

    def generate_response(self, query: str, sql_query: str, results: list) -> str:
        """
        Generate a natural language response from SQL results.

        Args:
            query: Original natural language query.
            sql_query: The SQL query that was executed.
            results: Query results (list of dicts).

        Returns:
            Natural language response.
        """
        results_str = self._format_results(results)
        prompt = f"""
        Original Question: {query}
        SQL Query Executed: {sql_query}
        Results: {results_str}
        
        Please provide a clear, concise answer to the original question based on the results above.
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a helpful assistant that converts database query results into clear, natural language responses."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.5,
                max_tokens=500,
            )
            
            answer = response.choices[0].message.content.strip()
            logger.info(f"Generated response: {answer[:100]}...")
            return answer
        except Exception as e:
            logger.error(f"Failed to generate response: {e}")
            return str(results)

    def _build_sql_prompt(self, user_query: str, schema_context: str, examples: str = "") -> str:
        """Build the prompt for SQL generation."""
        prompt = f"""
Generate a SQL SELECT query to answer the following question.

Database Schema:
{schema_context}

Question: {user_query}

{f"Examples:\\n{examples}" if examples else ""}

Requirements:
- Only use SELECT statements (no INSERT, UPDATE, DELETE, or DDL)
- Use table and column names exactly as defined in the schema
- For date filtering, use YYYY-MM-DD format
- Include appropriate JOINs if needed
- Use WHERE clauses for filtering
- Use ORDER BY for sorting (place DESC/ASC as needed)
- Use LIMIT for limiting results if not specified
- Ensure the query is properly formatted and executable

Return only the SQL query, no explanations or markdown formatting.
"""
        return prompt

    def _format_results(self, results: list, max_rows: int = 10) -> str:
        """Format query results for display."""
        if not results:
            return "No results found."
        
        # Limit display rows
        display_results = results[:max_rows]
        if len(results) > max_rows:
            display_results.append({"_note": f"... and {len(results) - max_rows} more rows"})
        
        return "\n".join([str(row) for row in display_results])
