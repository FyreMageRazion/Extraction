"""Executor for SQL generation, validation, and execution."""
import logging
from typing import Dict, Any, Tuple, Optional, List

from agent.db_adapter import DatabaseAdapter
from agent.schema_loader import SchemaLoader
from agent.llm_interface import LLMInterface
from agent.sql_validator import SQLValidator

logger = logging.getLogger(__name__)


class TextToSQLExecutor:
    """Execute text-to-SQL pipeline: generation, validation, and execution."""

    def __init__(
        self,
        db_adapter: DatabaseAdapter,
        schema_loader: SchemaLoader,
        llm_interface: LLMInterface,
        sql_validator: SQLValidator
    ):
        """
        Initialize executor.

        Args:
            db_adapter: Database adapter for query execution.
            schema_loader: Schema loader for context.
            llm_interface: LLM interface for SQL generation.
            sql_validator: SQL validator for safety checks.
        """
        self.db_adapter = db_adapter
        self.schema_loader = schema_loader
        self.llm_interface = llm_interface
        self.sql_validator = sql_validator

    def execute(self, user_query: str, include_response: bool = True) -> Dict[str, Any]:
        """
        Execute the full text-to-SQL pipeline.

        Args:
            user_query: Natural language query from the user.
            include_response: If True, generate a natural language response.

        Returns:
            Dictionary with:
            - user_query: Original query
            - sql_query: Generated SQL
            - is_valid: Whether SQL passed validation
            - results: Query results (list of dicts)
            - response: Natural language response (if include_response=True)
            - error: Error message if any step failed
        """
        result = {
            "user_query": user_query,
            "sql_query": None,
            "is_valid": False,
            "results": [],
            "response": None,
            "error": None
        }

        try:
            # Step 1: Generate SQL
            schema_context = self.schema_loader.get_schema_context()
            sql_query = self.llm_interface.generate_sql(user_query, schema_context)
            result["sql_query"] = sql_query
            logger.info(f"Generated SQL: {sql_query[:100]}...")

            # Step 2: Validate SQL
            is_valid, error_msg = self.sql_validator.validate(sql_query)
            result["is_valid"] = is_valid

            if not is_valid:
                result["error"] = f"Validation failed: {error_msg}"
                logger.warning(f"SQL validation failed: {error_msg}")
                return result

            # Step 3: Execute query
            sanitized_query = self.sql_validator.sanitize_query(sql_query)
            results = self.db_adapter.execute_query(sanitized_query)
            result["results"] = results
            logger.info(f"Query executed, returned {len(results)} rows")

            # Step 4: Generate natural language response (optional)
            if include_response and results:
                try:
                    response = self.llm_interface.generate_response(user_query, sql_query, results)
                    result["response"] = response
                except Exception as e:
                    logger.warning(f"Failed to generate response: {e}")
                    result["response"] = str(results)

            return result

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Execution failed: {e}")
            return result

    def execute_sql_only(self, sql_query: str) -> Tuple[bool, List[Dict[str, Any]], Optional[str]]:
        """
        Execute only a SQL query without generation.

        Args:
            sql_query: SQL query to execute.

        Returns:
            Tuple of (is_valid, results, error_message).
        """
        # Validate
        is_valid, error_msg = self.sql_validator.validate(sql_query)
        if not is_valid:
            return False, [], f"Validation failed: {error_msg}"

        # Execute
        try:
            sanitized_query = self.sql_validator.sanitize_query(sql_query)
            results = self.db_adapter.execute_query(sanitized_query)
            return True, results, None
        except Exception as e:
            return False, [], str(e)

    def batch_execute(self, queries: List[str]) -> List[Dict[str, Any]]:
        """
        Execute multiple queries in batch.

        Args:
            queries: List of natural language queries.

        Returns:
            List of execution results.
        """
        results = []
        for query in queries:
            result = self.execute(query)
            results.append(result)
        return results
