"""Database adapter for safe read-only SQLite operations."""
import sqlite3
from typing import List, Dict, Any, Optional
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class DatabaseAdapter:
    """Manage read-only SQLite connections with safety constraints."""

    def __init__(self, db_path: str, readonly: bool = True, timeout: int = 5, row_limit: int = 1000):
        """
        Initialize database adapter.

        Args:
            db_path: Path to SQLite database file.
            readonly: If True, connect in read-only mode.
            timeout: Query execution timeout in seconds.
            row_limit: Maximum rows returned per query.
        """
        self.db_path = str(db_path)
        self.readonly = readonly
        self.timeout = timeout
        self.row_limit = row_limit
        self.conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        """Establish database connection."""
        try:
            if self.readonly:
                # Read-only URI mode for SQLite
                uri = f"file:{self.db_path}?mode=ro"
                self.conn = sqlite3.connect(uri, uri=True, timeout=self.timeout)
            else:
                self.conn = sqlite3.connect(self.db_path, timeout=self.timeout)
            
            # Return results as Row objects for dict-like access
            self.conn.row_factory = sqlite3.Row
            logger.info(f"Connected to database: {self.db_path}")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise

    def disconnect(self) -> None:
        """Close database connection."""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")

    def execute_query(self, query: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        """
        Execute a SELECT query safely.

        Args:
            query: SQL SELECT query to execute.
            params: Query parameters for parameterized queries.

        Returns:
            List of result rows as dictionaries.

        Raises:
            ValueError: If query is not a SELECT statement.
            RuntimeError: If query execution fails.
        """
        if not self.conn:
            self.connect()

        try:
            cursor = self.conn.cursor()
            cursor.execute(query, params or [])
            
            # Fetch rows up to the limit
            rows = cursor.fetchmany(self.row_limit)
            
            # Convert Row objects to dicts
            results = [dict(row) for row in rows]
            
            logger.info(f"Query executed successfully, returned {len(results)} rows")
            return results
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise RuntimeError(f"Query execution error: {e}")

    def get_schema(self) -> Dict[str, Dict[str, Any]]:
        """
        Retrieve database schema information.

        Returns:
            Dictionary with table names as keys and column info as values.
        """
        if not self.conn:
            self.connect()

        schema = {}
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;")
            tables = cursor.fetchall()

            for (table_name,) in tables:
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns = cursor.fetchall()

                schema[table_name] = {
                    'columns': [
                        {
                            'name': col[1],
                            'type': col[2],
                            'notnull': bool(col[3]),
                            'pk': bool(col[5])
                        }
                        for col in columns
                    ]
                }

            logger.info(f"Schema retrieved: {len(schema)} tables")
            return schema
        except Exception as e:
            logger.error(f"Failed to retrieve schema: {e}")
            raise RuntimeError(f"Schema retrieval error: {e}")

    def get_table_sample(self, table_name: str, limit: int = 5) -> List[Dict[str, Any]]:
        """
        Get sample rows from a table.

        Args:
            table_name: Name of the table.
            limit: Number of sample rows to retrieve.

        Returns:
            List of sample rows as dictionaries.
        """
        query = f"SELECT * FROM {table_name} LIMIT ?"
        try:
            return self.execute_query(query, [limit])
        except Exception as e:
            logger.error(f"Failed to get sample from {table_name}: {e}")
            return []

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.disconnect()
