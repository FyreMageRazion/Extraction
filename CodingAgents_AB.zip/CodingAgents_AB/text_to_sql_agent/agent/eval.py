"""Evaluation harness for text-to-SQL agent."""
import csv
import logging
from typing import List, Dict, Any, Tuple
from pathlib import Path
import pandas as pd
from rapidfuzz import fuzz

from agent.executor import TextToSQLExecutor

logger = logging.getLogger(__name__)


class EvaluationHarness:
    """Evaluate text-to-SQL agent against test queries."""

    def __init__(self, executor: TextToSQLExecutor, match_threshold: float = 0.85):
        """
        Initialize evaluation harness.

        Args:
            executor: TextToSQLExecutor instance.
            match_threshold: Fuzzy match threshold (0.0-1.0).
        """
        self.executor = executor
        self.match_threshold = match_threshold

    def load_test_queries(self, csv_path: str) -> List[Dict[str, str]]:
        """
        Load test queries from CSV.

        Args:
            csv_path: Path to test_queries.csv file.

        Returns:
            List of query dictionaries.
        """
        queries = []
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                queries.append(row)
        logger.info(f"Loaded {len(queries)} test queries from {csv_path}")
        return queries

    def load_sample_responses(self, csv_path: str) -> Dict[str, str]:
        """
        Load sample responses from CSV.

        Args:
            csv_path: Path to sample_queries_with_responses.csv file.

        Returns:
            Dictionary mapping queries to expected responses.
        """
        responses = {}
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                query = row.get('query', '').strip()
                response = row.get('response', '').strip()
                if query:
                    responses[query] = response
        logger.info(f"Loaded {len(responses)} sample responses from {csv_path}")
        return responses

    def evaluate_query(self, user_query: str, expected_response: str = None) -> Dict[str, Any]:
        """
        Evaluate a single query.

        Args:
            user_query: Natural language query.
            expected_response: Expected response (optional).

        Returns:
            Evaluation result dictionary.
        """
        result = {
            "query": user_query,
            "expected_response": expected_response,
            "generated_sql": None,
            "results": [],
            "generated_response": None,
            "sql_valid": False,
            "response_match": None,
            "match_score": 0.0,
            "error": None,
            "passed": False
        }

        try:
            # Execute query
            exec_result = self.executor.execute(user_query, include_response=True)

            result["generated_sql"] = exec_result.get("sql_query")
            result["sql_valid"] = exec_result.get("is_valid", False)
            result["results"] = exec_result.get("results", [])
            result["generated_response"] = exec_result.get("response")
            result["error"] = exec_result.get("error")

            if not result["sql_valid"]:
                logger.warning(f"Query failed: {result['error']}")
                return result

            # Evaluate response if expected
            if expected_response:
                match_score = self._calculate_response_similarity(
                    result["generated_response"],
                    expected_response
                )
                result["match_score"] = match_score
                result["response_match"] = match_score >= self.match_threshold
                result["passed"] = result["sql_valid"] and result["response_match"]
            else:
                result["passed"] = result["sql_valid"]

            return result

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"Evaluation failed: {e}")
            return result

    def evaluate_batch(self, test_queries: List[Dict[str, str]], 
                      sample_responses: Dict[str, str] = None) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Evaluate multiple queries.

        Args:
            test_queries: List of test query dictionaries.
            sample_responses: Dictionary of sample responses.

        Returns:
            Tuple of (results list, summary dict).
        """
        results = []
        
        for test_query in test_queries:
            query = test_query.get('query', '').strip()
            if not query:
                continue

            # Get expected response if available
            expected = None
            if sample_responses:
                expected = sample_responses.get(query) or sample_responses.get(query.rstrip('.'))

            eval_result = self.evaluate_query(query, expected)
            results.append(eval_result)

        # Generate summary
        summary = self._generate_summary(results)
        return results, summary

    def _calculate_response_similarity(self, generated: str, expected: str) -> float:
        """
        Calculate similarity between generated and expected responses.

        Args:
            generated: Generated response.
            expected: Expected response.

        Returns:
            Similarity score (0.0-1.0).
        """
        if not generated or not expected:
            return 0.0
        
        # Use token_set_ratio for more flexible matching
        similarity = fuzz.token_set_ratio(generated, expected) / 100.0
        return similarity

    def _generate_summary(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate evaluation summary."""
        total = len(results)
        passed = sum(1 for r in results if r.get("passed"))
        sql_valid = sum(1 for r in results if r.get("sql_valid"))
        
        # Calculate average match score for responses
        match_scores = [r.get("match_score", 0) for r in results if r.get("match_score") is not None]
        avg_match_score = sum(match_scores) / len(match_scores) if match_scores else 0.0

        summary = {
            "total_queries": total,
            "passed": passed,
            "failed": total - passed,
            "pass_rate": passed / total if total > 0 else 0.0,
            "sql_valid_count": sql_valid,
            "sql_valid_rate": sql_valid / total if total > 0 else 0.0,
            "avg_response_match_score": avg_match_score
        }

        return summary

    def save_results(self, results: List[Dict[str, Any]], output_path: str) -> None:
        """
        Save evaluation results to CSV.

        Args:
            results: List of evaluation results.
            output_path: Path to save results.
        """
        df = pd.DataFrame(results)
        df.to_csv(output_path, index=False, encoding='utf-8')
        logger.info(f"Results saved to {output_path}")

    def print_summary(self, summary: Dict[str, Any]) -> None:
        """Print evaluation summary."""
        print("\n" + "=" * 70)
        print("EVALUATION SUMMARY")
        print("=" * 70)
        print(f"Total Queries:        {summary['total_queries']}")
        print(f"Passed:               {summary['passed']}")
        print(f"Failed:               {summary['failed']}")
        print(f"Pass Rate:            {summary['pass_rate']:.2%}")
        print(f"SQL Valid Rate:       {summary['sql_valid_rate']:.2%}")
        print(f"Avg Response Match:   {summary['avg_response_match_score']:.2%}")
        print("=" * 70 + "\n")
