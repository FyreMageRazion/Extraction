#!/usr/bin/env python
"""Initialize Text-to-SQL Agent System."""
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agent import DatabaseAdapter, SchemaLoader, LLMInterface
from crewai_orchestrator import TextToSQLCrewOrchestrator


def main():
    """Initialize and demonstrate the system."""
    
    print("\n" + "="*70)
    print("TEXT-TO-SQL AGENTIC AI SYSTEM - INITIALIZATION")
    print("="*70)
    
    # Load environment
    load_dotenv()
    
    # Verify OPENAI_API_KEY
    if not os.getenv("OPENAI_API_KEY"):
        print("\n❌ Error: OPENAI_API_KEY not set")
        print("   Please create a .env file with your OpenAI API key:")
        print("   OPENAI_API_KEY=sk-...")
        sys.exit(1)
    
    print("\n✓ OPENAI_API_KEY configured")
    
    # Find database
    db_path = Path(__file__).parent.parent / "problem_statement_task" / "banking_insights.db"
    
    if not db_path.exists():
        print(f"\n❌ Error: Database not found at {db_path}")
        sys.exit(1)
    
    print(f"✓ Database found: {db_path}")
    
    # Initialize orchestrator
    print("\n📦 Initializing components...")
    
    try:
        with TextToSQLCrewOrchestrator(str(db_path)) as orchestrator:
            print("✓ CrewAI Orchestrator initialized")
            
            # Display schema
            print("\n📊 Database Tables:")
            for table in orchestrator.schema_loader.tables:
                cols = len(orchestrator.schema_loader.get_table_columns(table))
                print(f"   • {table} ({cols} columns)")
            
            # Test a sample query
            print("\n🧪 Testing with sample query...")
            test_query = "Top 5 customers by total debit spend"
            print(f"   Query: {test_query}")
            
            result = orchestrator.process_query(test_query)
            
            if result.get('error'):
                print(f"   ❌ Error: {result['error']}")
            elif not result.get('is_valid'):
                print(f"   ❌ SQL Validation failed")
            else:
                print(f"   ✓ Success ({len(result['results'])} rows)")
                print(f"   ✓ SQL: {result['sql_query'][:50]}...")
        
        print("\n" + "="*70)
        print("✓ INITIALIZATION SUCCESSFUL")
        print("="*70)
        print("\nNext Steps:")
        print("  1. Review the Jupyter notebook: notebooks/demo.ipynb")
        print("  2. Run tests: python scripts/run_tests.py")
        print("  3. Modify .env to adjust model or API endpoints")
        print("\nDocumentation: See README.md for detailed usage instructions")
        print("="*70 + "\n")
        
    except Exception as e:
        print(f"\n❌ Initialization failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
