#!/usr/bin/env python
"""Evaluation runner script for text-to-SQL agent."""
import os
import sys
import logging
import argparse
from pathlib import Path
from dotenv import load_dotenv

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agent import DatabaseAdapter, SchemaLoader, LLMInterface, SQLValidator, TextToSQLExecutor
from agent.eval import EvaluationHarness

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """Run evaluation."""
    parser = argparse.ArgumentParser(description="Evaluate Text-to-SQL Agent")
    parser.add_argument(
        "--db",
        default="../problem_statement_task/banking_insights.db",
        help="Path to SQLite database"
    )
    parser.add_argument(
        "--test-queries",
        default="../problem_statement_task/test_queries.csv",
        help="Path to test queries CSV"
    )
    parser.add_argument(
        "--sample-responses",
        default="../problem_statement_task/sample_queries_with_responses.csv",
        help="Path to sample responses CSV"
    )
    parser.add_argument(
        "--output",
        default="evaluation_results.csv",
        help="Output file for results"
    )
    parser.add_argument(
        "--api-key",
        help="OpenAI API key (uses OPENAI_API_KEY env var if not provided)"
    )
    parser.add_argument(
        "--model",
        default="gpt-4o-mini",
        help="LLM model to use (default: gpt-4o-mini)"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose output"
    )

    args = parser.parse_args()

    # Load environment
    load_dotenv()

    # Validate files exist
    db_path = Path(args.db)
    test_queries_path = Path(args.test_queries)
    sample_responses_path = Path(args.sample_responses)

    if not db_path.exists():
        logger.error(f"Database not found: {db_path}")
        sys.exit(1)

    if not test_queries_path.exists():
        logger.error(f"Test queries file not found: {test_queries_path}")
        sys.exit(1)

    logger.info(f"Database: {db_path}")
    logger.info(f"Test Queries: {test_queries_path}")

    try:
        # Initialize components
        logger.info("Initializing components...")
        db_adapter = DatabaseAdapter(str(db_path), readonly=True)
        db_adapter.connect()

        schema_loader = SchemaLoader.from_db_adapter(db_adapter)
        llm_interface = LLMInterface(api_key=args.api_key, model=args.model)
        sql_validator = SQLValidator(schema_allowlist=schema_loader.get_allowlist())
        executor = TextToSQLExecutor(db_adapter, schema_loader, llm_interface, sql_validator)

        # Create evaluation harness
        eval_harness = EvaluationHarness(executor, match_threshold=0.85)

        # Load test queries
        logger.info("Loading test queries...")
        test_queries = eval_harness.load_test_queries(str(test_queries_path))

        # Load sample responses
        sample_responses = None
        if sample_responses_path.exists():
            logger.info("Loading sample responses...")
            sample_responses = eval_harness.load_sample_responses(str(sample_responses_path))

        # Run evaluation
        logger.info(f"Running evaluation on {len(test_queries)} queries...")
        results, summary = eval_harness.evaluate_batch(test_queries, sample_responses)

        # Save results
        eval_harness.save_results(results, args.output)
        logger.info(f"Results saved to {args.output}")

        # Print summary
        eval_harness.print_summary(summary)

        # Print detailed results
        if args.verbose:
            print("\n" + "=" * 70)
            print("DETAILED RESULTS")
            print("=" * 70)
            for i, result in enumerate(results, 1):
                print(f"\nQuery {i}: {result['query']}")
                print(f"  SQL Valid: {result['sql_valid']}")
                if result['generated_sql']:
                    print(f"  Generated SQL: {result['generated_sql'][:80]}...")
                if result['error']:
                    print(f"  Error: {result['error']}")
                if result.get('match_score') is not None:
                    print(f"  Match Score: {result['match_score']:.2%}")
                print(f"  Passed: {result['passed']}")

        # Clean up
        db_adapter.disconnect()

    except Exception as e:
        logger.error(f"Evaluation failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
