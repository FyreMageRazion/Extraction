"""CrewAI orchestrator for text-to-SQL agent system."""
import logging
from typing import Optional, Dict, Any

from agent.db_adapter import DatabaseAdapter
from agent.schema_loader import SchemaLoader
from agent.llm_interface import LLMInterface
from agent.sql_validator import SQLValidator
from agent.executor import TextToSQLExecutor

# Optional: Import CrewAI if available
try:
    from crewai import Agent, Task, Crew
    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False
    logger = logging.getLogger(__name__)
    logger.warning("CrewAI not available or not properly installed")

logger = logging.getLogger(__name__)


class TextToSQLCrewOrchestrator:
    """Orchestrate text-to-SQL system using CrewAI."""

    def __init__(
        self,
        db_path: str,
        api_key: Optional[str] = None,
        model: str = "gpt-4o-mini"
    ):
        """
        Initialize CrewAI orchestrator.

        Args:
            db_path: Path to SQLite database.
            api_key: OpenAI API key (if None, read from env).
            model: LLM model to use.
        """
        self.db_path = db_path
        self.api_key = api_key
        self.model = model

        # Initialize components
        self.db_adapter = DatabaseAdapter(db_path, readonly=True)
        self.db_adapter.connect()
        
        self.schema_loader = SchemaLoader.from_db_adapter(self.db_adapter)
        self.llm_interface = LLMInterface(api_key=api_key, model=model)
        self.sql_validator = SQLValidator(schema_allowlist=self.schema_loader.get_allowlist())
        self.executor = TextToSQLExecutor(
            self.db_adapter,
            self.schema_loader,
            self.llm_interface,
            self.sql_validator
        )

        self.crew = self._build_crew()
        logger.info("CrewAI orchestrator initialized")

    def _build_crew(self) -> Optional['Crew']:
        """Build the CrewAI crew with agents and tasks (optional)."""
        if not CREWAI_AVAILABLE:
            logger.info("CrewAI not available - using direct executor")
            return None
        
        try:
            # Define agent tasks
            sql_generator_agent = Agent(
                role="SQL Query Generator",
                goal="Convert natural language questions into accurate SQL queries",
                backstory="""You are an expert database analyst with deep knowledge of SQL.
Your task is to understand user questions and generate precise, efficient SQL queries.
Always ensure queries are read-only (SELECT only) and use proper JOINs when needed.""",
                verbose=True,
                allow_delegation=False
            )

            sql_validator_agent = Agent(
                role="SQL Validator",
                goal="Ensure SQL queries are safe, valid, and follow security best practices",
                backstory="""You are a security expert focusing on SQL injection prevention and query safety.
Your role is to validate that SQL queries are safe to execute and only perform read operations.""",
                verbose=True,
                allow_delegation=False
            )

            query_executor_agent = Agent(
                role="Query Executor",
                goal="Execute validated SQL queries and return results",
                backstory="""You are a database executor responsible for safely running SQL queries.
You handle execution timeouts, row limits, and result formatting.""",
                verbose=True,
                allow_delegation=False
            )

            # Create tasks
            sql_generation_task = Task(
                description="Generate a SQL query for: {user_query}",
                agent=sql_generator_agent,
                expected_output="A valid SQL SELECT query"
            )

            sql_validation_task = Task(
                description="Validate the generated SQL query: {sql_query}",
                agent=sql_validator_agent,
                expected_output="Validation status and any errors found"
            )

            query_execution_task = Task(
                description="Execute the validated SQL query: {sql_query}",
                agent=query_executor_agent,
                expected_output="Query results and execution status"
            )

            # Create crew
            crew = Crew(
                agents=[sql_generator_agent, sql_validator_agent, query_executor_agent],
                tasks=[sql_generation_task, sql_validation_task, query_execution_task],
                verbose=True,
                memory=False
            )

            return crew
        except Exception as e:
            logger.warning(f"Failed to build CrewAI crew: {e}")
            return None

    def process_query(self, user_query: str) -> Dict[str, Any]:
        """
        Process a user query through the crew.

        Args:
            user_query: Natural language query from user.

        Returns:
            Dictionary with query, SQL, results, and response.
        """
        logger.info(f"Processing query: {user_query}")
        
        # Use the simpler executor directly for better control
        result = self.executor.execute(user_query, include_response=True)
        return result

    def close(self):
        """Close database connection."""
        self.db_adapter.disconnect()
        logger.info("Orchestrator closed")

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
