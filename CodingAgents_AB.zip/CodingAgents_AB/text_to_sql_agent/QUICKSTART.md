# Quick Start Guide - Text-to-SQL Agentic AI System

## 🚀 5-Minute Setup

### Step 1: Set Up Environment (1 min)

```bash
cd text_to_sql_agent

# Copy the example environment file
cp .env.example .env

# Edit .env and add your OpenAI API key (get from https://platform.openai.com/api-keys)
# OPENAI_API_KEY=sk-...
```

### Step 2: Install Dependencies (2 min)

```bash
# Install all required packages
pip install -r requirements.txt
```

### Step 3: Verify Installation (1 min)

```bash
# Run the initialization script to verify everything works
python init.py
```

Expected output:
```
[OK] OPENAI_API_KEY configured
[OK] Database found: ...
[OK] CrewAI Orchestrator initialized
[OK] Testing with sample query...
[OK] Success (N rows)

[SUCCESS] INITIALIZATION SUCCESSFUL
```

### Step 4: Run the Demo (1 min)

```bash
# Launch Jupyter notebook
jupyter notebook notebooks/demo.ipynb
```

## 📕 Using the Notebook

The notebook (`notebooks/demo.ipynb`) provides a complete walkthrough:

1. **Setup & Configuration** - Initialize the environment
2. **Database Schema** - Inspect tables and columns
3. **Sample Queries** - See example queries in action
4. **Full Evaluation** - Run against all test queries
5. **Results Analysis** - View detailed metrics

Cell 1 sets up everything. Then run cells sequentially to see the full system in action.

## 🔧 Usage Examples

### Example 1: Run in Python Script

```python
from crewai_orchestrator import TextToSQLCrewOrchestrator
import os

os.chdir('text_to_sql_agent')

with TextToSQLCrewOrchestrator(
    db_path="../problem_statement_task/banking_insights.db"
) as orchestrator:
    result = orchestrator.process_query("Top 5 merchants by debit spend in July 2025")
    print(result['response'])
```

### Example 2: Run Evaluation Script

```bash
cd text_to_sql_agent
python scripts/run_tests.py \
    --db ../problem_statement_task/banking_insights.db \
    --test-queries ../problem_statement_task/test_queries.csv \
    --sample-responses ../problem_statement_task/sample_queries_with_responses.csv \
    --output evaluation_results.csv \
    --verbose
```

### Example 3: Direct Python Usage

```python
from agent import DatabaseAdapter, SchemaLoader, LLMInterface, SQLValidator, TextToSQLExecutor

# Initialize components
db = DatabaseAdapter("../problem_statement_task/banking_insights.db")
db.connect()

schema = SchemaLoader.from_db_adapter(db)
llm = LLMInterface()  # Reads OPENAI_API_KEY from env
validator = SQLValidator(schema_allowlist=schema.get_allowlist())
executor = TextToSQLExecutor(db, schema, llm, validator)

# Execute a query
result = executor.execute("Top customers by spending", include_response=True)
print(f"SQL: {result['sql_query']}")
print(f"Results: {len(result['results'])} rows")
print(f"Response: {result['response']}")

db.disconnect()
```

## 🗂️ Project Structure

```
text_to_sql_agent/
├── agent/                          # Core agent modules
│   ├── db_adapter.py              # Database connection and execution
│   ├── schema_loader.py           # Schema introspection
│   ├── llm_interface.py           # OpenAI integration
│   ├── sql_validator.py           # SQL safety validation
│   ├── executor.py                # Main execution pipeline
│   └── eval.py                    # Evaluation harness
├── notebooks/
│   └── demo.ipynb                 # Complete demo notebook
├── scripts/
│   └── run_tests.py               # Evaluation runner
├── crewai_orchestrator.py         # CrewAI orchestration
├── init.py                        # Initialization script
├── requirements.txt               # Python dependencies
├── .env.example                   # Environment template
├── README.md                      # Full documentation
└── QUICKSTART.md                  # This file
```

## 🧪 Test Queries

The system comes with 10+ test queries:

- "Top 5 merchants by debit spend in July 2025"
- "Count active accounts by account type"
- "Top 5 customers by total debit spend"
- "List the top 3 spending categories by total transaction value"
- "Which branch has the highest number of customers"
- "Top 5 highest-value transactions in 2025"
- And more in `problem_statement_task/test_queries.csv`

## ⚙️ Configuration

### Environment Variables

- `OPENAI_API_KEY` - Your OpenAI API key (required)
- `OPENAI_MODEL` - Model to use (default: gpt-4o-mini)
- `LOG_LEVEL` - Logging verbosity (default: INFO)

### Agent Configuration

Edit values in `agent/executor.py`:
- `timeout` - Query execution timeout (default: 5s)
- `row_limit` - Max rows returned (default: 1000)
- `temperature` - LLM randomness (default: 0.0)

## 🔒 Safety Features

The system includes multiple layers of safety:

1. **SQL-Only Queries**: Enforces SELECT statements only
2. **Schema Validation**: Whitelists allowed tables and columns
3. **Injection Prevention**: No SQL comments or dangerous keywords
4. **Execution Limits**: Timeouts and row limits
5. **Read-Only Database**: SQLite readonly URI mode

## 📊 Expected Results

After running the demo, you should see:
- Pass rate: 60-80% (depends on LLM accuracy)
- SQL valid rate: 90%+ (most queries pass validation)
- Average response match: 70-85%

Example summary:
```
Pass Rate:            75.00%
SQL Valid Rate:       95.00%
Avg Response Match:   78.00%
```

## 🐛 Troubleshooting

### Error: OPENAI_API_KEY not set
**Solution**: 
```bash
# Add to .env file:
OPENAI_API_KEY=sk-your-key-here
```

### Error: Database not found
**Solution**:
- Verify path to `banking_insights.db` is correct
- Check file exists in `problem_statement_task/`

### Slow query execution
**Solution**:
- First request is slower (LLM initialization)
- Subsequent requests should be faster
- Consider using faster model like `gpt-4o-mini`

### Import errors
**Solution**:
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

## 💡 Tips

1. **Test single queries first** - Use the notebook for interactive testing
2. **Check generated SQL** - Review SQL before assuming query failed
3. **Start with sample queries** - Use examples as templates
4. **Monitor API costs** - Check OpenAI usage dashboard
5. **Run evaluation regularly** - Track system performance over time

## 📚 Next Steps

1. Review [README.md](README.md) for complete documentation
2. Explore the Jupyter notebook cells interactively
3. Modify prompts in `llm_interface.py` to improve accuracy
4. Add custom queries to test system capabilities
5. Integrate into your application using the executor module

## 🆘 Getting Help

1. Check the notebook for working examples
2. Review error messages in `evaluation_results.csv`
3. Verify database schema in the demo notebook (cell 3)
4. Check SQL validation rules in `agent/sql_validator.py`

---

**You're ready to go! Start with: `jupyter notebook notebooks/demo.ipynb`**
