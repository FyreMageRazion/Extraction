# Text-to-SQL Agentic AI System

A CrewAI-based agent system that converts natural language queries into SQL and executes them against a banking database safely and securely.

## Features

- **Natural Language to SQL**: Converts user questions to accurate SQL queries using GPT-4o-mini
- **SQL Validation**: Enforces read-only operations and prevents SQL injection
- **Safe Execution**: Sandboxed query execution with timeouts and row limits
- **CrewAI Integration**: Multi-agent orchestration for reliable SQL generation and validation
- **Comprehensive Evaluation**: Strict exact-match evaluation against test queries
- **Jupyter Notebook Demo**: Interactive notebook for testing and demonstration

## Architecture

```
User Query (NL)
    ↓
LLM Interface (OpenAI)
    ↓
SQL Generator (LLM)
    ↓
SQL Validator (Security Checks)
    ↓
Database Adapter (Safe Execution)
    ↓
Results + NL Response (LLM)
```

## Installation

### Prerequisites

- Python 3.10+
- OpenAI API key (get from https://platform.openai.com/api-keys)
- SQLite database (included: `problem_statement_task/banking_insights.db`)

### Steps

1. **Clone/Navigate to project**:
   ```bash
   cd text_to_sql_agent
   ```

2. **Create environment file**:
   ```bash
   cp .env.example .env
   # Edit .env and add your OPENAI_API_KEY
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Set environment variable** (if not using .env file):
   ```bash
   # On Windows (PowerShell)
   $env:OPENAI_API_KEY = "your_api_key_here"
   
   # On macOS/Linux
   export OPENAI_API_KEY="your_api_key_here"
   ```

## Usage

### 1. Jupyter Notebook Demo (Recommended)

```bash
jupyter notebook notebooks/demo.ipynb
```

The notebook includes:
- Schema introspection
- Sample query execution
- Full evaluation of test queries
- Results visualization

### 2. Python Script

```python
from crewai_orchestrator import TextToSQLCrewOrchestrator

# Initialize orchestrator
with TextToSQLCrewOrchestrator(
    db_path="../problem_statement_task/banking_insights.db"
) as orchestrator:
    # Execute a query
    result = orchestrator.process_query("Top 5 customers by total debit spend")
    print(result)
```

### 3. Evaluation Script

```bash
python scripts/run_tests.py
```

## Database Schema

The system works with a banking database containing:

- **Customer**: Customer information (ID, Name, City, State)
- **Branch**: Bank branch details (ID, Name, City, State)
- **Account**: Customer accounts (ID, CustomerID, BranchID, AccountType, OpenDate, Status)
- **Merchant**: Merchant information (ID, Name)
- **Transactions**: Transaction records (TxnID, AccountID, TxnDate, AmountINR, TxnType, Channel, MerchantID, Category, Description)
- **Dispute**: Transaction disputes (ID, TxnID, RaisedDate, ReasonCode, Status, Resolution)

## Configuration

### Environment Variables

- `OPENAI_API_KEY`: Your OpenAI API key (required)
- `OPENAI_MODEL`: Model to use (default: gpt-4o-mini)
- `LOG_LEVEL`: Logging level (default: INFO)

### Agent Configuration

Modify `agent/executor.py` to adjust:
- `timeout`: Query execution timeout (default: 5s)
- `row_limit`: Maximum rows returned (default: 1000)
- `temperature`: LLM randomness (default: 0.0 for deterministic)

## Safety Features

1. **SQL Validation**:
   - Only allows SELECT queries
   - Forbids INSERT, UPDATE, DELETE, DROP, ALTER, etc.
   - No SQL comments allowed
   - Schema-based table/column allowlist

2. **Execution Sandboxing**:
   - Read-only SQLite URI mode
   - Query timeout (5 seconds)
   - Row limit (1000 rows)
   - Parameterized query execution

3. **LLM Constraints**:
   - Explicit system prompt enforcing SELECT-only
   - Schema context limiting table references
   - Few-shot examples of safe queries

## Evaluation

The system includes strict exact-match evaluation:

1. Loads test queries from `problem_statement_task/test_queries.csv`
2. Compares expected responses from `problem_statement_task/sample_queries_with_responses.csv`
3. Uses fuzzy string matching (85% threshold by default)
4. Generates per-query pass/fail and overall metrics

**Metrics**:
- Pass Rate: % of queries with valid SQL and matching responses
- SQL Valid Rate: % of queries that passed SQL validation
- Average Response Match: Average fuzzy match score

## Project Structure

```
text_to_sql_agent/
├── agent/
│   ├── __init__.py
│   ├── db_adapter.py          # Database connection and execution
│   ├── schema_loader.py       # Schema introspection and context
│   ├── llm_interface.py       # OpenAI API wrapper
│   ├── sql_validator.py       # SQL safety validation
│   ├── executor.py            # Main execution pipeline
│   └── eval.py                # Evaluation harness
├── notebooks/
│   └── demo.ipynb             # Jupyter notebook demonstration
├── scripts/
│   └── run_tests.py           # Evaluation runner script
├── crewai_orchestrator.py     # CrewAI multi-agent orchestration
├── requirements.txt            # Python dependencies
├── .env.example               # Environment configuration template
└── README.md                  # This file

../problem_statement_task/
├── banking_insights.db        # SQLite database
├── test_queries.csv           # Test queries to evaluate
└── sample_queries_with_responses.csv  # Expected responses
```

## Example Queries

The system can handle various queries:

- "Top 5 merchants by debit spend in July 2025"
- "Top 5 customers by total debit spend"
- "Count active accounts by account type"
- "Show the top 5 highest-value transactions in 2025 with customer and merchant details"
- "Which branch has the highest number of customers"

## Troubleshooting

### Issue: `OPENAI_API_KEY not set`
**Solution**: 
- Check that `OPENAI_API_KEY` is set in `.env` or environment
- Run `echo $OPENAI_API_KEY` to verify (macOS/Linux)
- Or set directly: `$env:OPENAI_API_KEY = "sk-..."`

### Issue: Database connection fails
**Solution**:
- Ensure `banking_insights.db` exists in `problem_statement_task/`
- Check file path is correct in your code

### Issue: SQL generation is slow
**Solution**:
- This is normal for first requests (LLM initialization)
- Subsequent requests should be faster
- Consider using a faster model like `gpt-4o-mini`

### Issue: Results don't match expected
**Solution**:
- Check SQL query generated in the result
- Run the query manually in SQLite browser to verify
- Adjust prompt engineering in `llm_interface.py` if needed

## License

This capstone project is provided for educational purposes.

## Support

For issues or questions:
1. Check the Jupyter notebook demo for working examples
2. Review the test queries in `problem_statement_task/test_queries.csv`
3. Examine generated SQL in the output results
