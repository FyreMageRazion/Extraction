import csv
import os
from dotenv import load_dotenv
from agent.core import TextToSqlAgent


def run_all(test_csv: str = "problem_statement_task/test_queries.csv", out_csv: str = "submission.csv"):
    load_dotenv()
    agent = TextToSqlAgent(db_path=os.environ.get("DB_PATH", "problem_statement_task/banking_insights.db"), schema_path="artifacts/schema.json")

    rows = []
    with open(test_csv, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            q = r.get('query')
            print("Running:", q)
            try:
                out = agent.answer_query(q, max_rows=10, debug=False)
                if out.get('error'):
                    resp = out.get('error')
                else:
                    resp = out.get('answer')
            except Exception as e:
                resp = f"ERROR: {e}"
            rows.append({'query': q, 'response': resp})

    with open(out_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['query', 'response'])
        writer.writeheader()
        for r in rows:
            writer.writerow(r)


if __name__ == '__main__':
    run_all()
