import os
from pathlib import Path
from pypdf import PdfReader


def extract_pdf_to_text(pdf_path: str, out_txt: str):
    reader = PdfReader(pdf_path)
    texts = []
    for p in reader.pages:
        try:
            texts.append(p.extract_text() or "")
        except Exception:
            texts.append("")
    all_text = "\n\n".join(texts)
    with open(out_txt, "w", encoding="utf-8") as f:
        f.write(all_text)
    return all_text


def main():
    base = Path("problem_statement_task")
    out_dir = Path("artifacts/pdfs")
    out_dir.mkdir(parents=True, exist_ok=True)
    for pdf in base.glob("*.pdf"):
        out = out_dir / (pdf.stem + ".txt")
        print(f"Extracting {pdf} -> {out}")
        try:
            extract_pdf_to_text(str(pdf), str(out))
        except Exception as e:
            print(f"Failed {pdf}: {e}")


if __name__ == "__main__":
    main()

