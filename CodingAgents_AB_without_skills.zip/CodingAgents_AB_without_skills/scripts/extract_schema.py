import argparse
import sqlite3
import json
import os
import csv


def extract(db_path: str, out_path: str):
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"DB not found: {db_path}")

    conn = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True)
    cursor = conn.cursor()

    cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
    tables = cursor.fetchall()

    schema = {}
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    artifacts_dir = os.path.join(os.path.dirname(out_path), "samples")
    os.makedirs(artifacts_dir, exist_ok=True)

    for name, ddl in tables:
        cursor.execute(f"PRAGMA table_info('{name}')")
        cols = cursor.fetchall()
        colinfo = [{"cid": c[0], "name": c[1], "type": c[2], "notnull": c[3], "dflt_value": c[4], "pk": c[5]} for c in cols]
        # sample rows
        try:
            cur = conn.cursor()
            cur.execute(f"SELECT * FROM '{name}' LIMIT 5;")
            rows = cur.fetchall()
            cols = [d[0] for d in cur.description] if cur.description else []
            sample = [dict(zip(cols, r)) for r in rows]
            # write CSV sample
            if cols:
                with open(os.path.join(artifacts_dir, f"{name}.sample.csv"), "w", newline='', encoding='utf-8') as csvf:
                    writer = csv.writer(csvf)
                    writer.writerow(cols)
                    for r in rows:
                        writer.writerow(r)
        except Exception:
            sample = []

        schema[name] = {"ddl": ddl, "columns": colinfo, "sample_rows": sample}

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(schema, f, indent=2, default=str)

    conn.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True, help="Path to SQLite DB")
    parser.add_argument("--out", required=True, help="Output schema JSON path")
    args = parser.parse_args()

    extract(args.db, args.out)


if __name__ == "__main__":
    main()
