import os
os.environ['PYTHONPATH'] = os.getcwd()
from agent.core import TextToSqlAgent
from dotenv import load_dotenv

load_dotenv()

a = TextToSqlAgent(db_path='problem_statement_task/banking_insights.db', schema_path='artifacts/schema.json')
result = a.answer_query('Top 5 merchants by debit spend in July 2025.', debug=True)
print(result)
