import os
import json
import re
import sqlite3
from typing import Optional, Dict, Any

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

from sqlglot import parse_one, exp


class TextToSqlAgent:
    def __init__(self, db_path: Optional[str] = None, schema_path: Optional[str] = None, openai_api_key: Optional[str] = None, model: Optional[str] = None):
        self.db_path = db_path
        self.schema = {}
        # allow overriding model via env var; default to gpt-4.1-mini per spec
        self.model = model or os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
        self.client = None
        if OpenAI is not None:
            api_key = openai_api_key or os.environ.get("OPENAI_API_KEY")
            if api_key:
                self.client = OpenAI(api_key=api_key)

        if schema_path and os.path.exists(schema_path):
            with open(schema_path, "r", encoding="utf-8") as f:
                self.schema = json.load(f)

    def _schema_text(self, max_chars=2000) -> str:
        parts = []
        for t, info in self.schema.items():
            cols = ", ".join([c["name"] + ':' + (c.get("type") or "TEXT") for c in info.get("columns", [])])
            parts.append(f"{t}({cols})")
        text = "\n".join(parts)
        return text[:max_chars]

    def generate_sql(self, user_query: str, few_shot: Optional[str] = None) -> str:
        system_msg = "You are a SQL generator. Produce a single read-only SQL SELECT query that answers the user's request. Do not produce DML or DDL. Use explicit JOIN ... ON clauses and avoid SELECT *."
        schema_snippet = self._schema_text()
        # load prompt template if available
        try:
            with open("prompts/template.txt", "r", encoding="utf-8") as f:
                tpl = f.read()
        except Exception:
            tpl = None

        if tpl:
            prompt = tpl.replace("{SCHEMA_SNIPPET}", schema_snippet)
            prompt = prompt + f"\n\nUser question: {user_query}\nReturn only the SQL SELECT statement."
        else:
            prompt = f"Schema:\n{schema_snippet}\n\nUser question: {user_query}\n\nReturn only the SQL SELECT statement."
        if few_shot:
            prompt = few_shot + "\n\n" + prompt

        if self.client is None:
            raise RuntimeError("OpenAI client not initialized. Provide OPENAI_API_KEY env var or constructor arg.")

        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "system", "content": system_msg}, {"role": "user", "content": prompt}],
            temperature=0,
            max_tokens=800,
        )
        sql = resp.choices[0].message.content.strip()
        # strip markdown fences if present
        sql = re.sub(r"^```sql\\n|^```\\n|```$", "", sql, flags=re.I).strip()
        return sql

    def validate_sql(self, sql: str, debug: bool = False) -> bool:
        # Enforce read-only: no DML/DDL
        forbidden = ["insert ", "update ", "delete ", "drop ", "create ", "alter ", "attach "]
        low = sql.lower()
        if ";" in low:
            if debug: print("Validation failed: semicolon found")
            return False
        for f in forbidden:
            if f in low:
                if debug: print(f"Validation failed: forbidden word '{f}' found")
                return False

        try:
            expr = parse_one(sql)
        except Exception as e:
            if debug: print(f"Validation failed: parse error {e}")
            return False

        # Must be a SELECT
        if not isinstance(expr, exp.Select):
            if debug: print(f"Validation failed: not a SELECT, type={type(expr)}")
            return False

        # Disallow SELECT *
        for star in expr.find_all(exp.Star):
            if debug: print("Validation failed: SELECT * found")
            return False

        # Enforce JOINs have ON conditions (if multiple tables in FROM)
        from_ = expr.args.get("from")
        if from_:
            tables = list(from_.find_all(exp.Table))
            joins = list(expr.find_all(exp.Join))
            if len(tables) > 1 and not joins:
                if debug: print(f"Validation failed: {len(tables)} tables but no JOINs")
                return False
            for j in joins:
                if not j.args.get("on"):
                    if debug: print("Validation failed: JOIN without ON")
                    return False

        # Validate only table names (lenient on columns since they can be in functions, aliases, etc.)
        if self.schema:
            referenced_tables = {t.name for t in expr.find_all(exp.Table)}
            schema_tables = {k.lower(): k for k in self.schema.keys()}
            if debug: print(f"DEBUG: referenced_tables={referenced_tables}, schema_tables={schema_tables}")
            for rt in referenced_tables:
                if rt.lower() not in schema_tables:
                    if debug: print(f"Validation failed: table '{rt}' not in schema")
                    return False

        return True

    def execute_sql(self, sql: str, limit: int = 1000) -> Dict[str, Any]:
        if not self.db_path:
            raise ValueError("No DB path configured for execution")

        # enforce read-only and limit
        if "limit" not in sql.lower():
            sql = sql.strip().rstrip(";") + f" LIMIT {limit}"

        conn = sqlite3.connect(f'file:{self.db_path}?mode=ro', uri=True)
        try:
            if pd is not None:
                df = pd.read_sql_query(sql, conn)
                return {"rows": df.to_dict(orient="records"), "columns": list(df.columns)}
            else:
                cur = conn.cursor()
                cur.execute(sql)
                rows = cur.fetchall()
                cols = [d[0] for d in cur.description] if cur.description else []
                records = [dict(zip(cols, r)) for r in rows]
                return {"rows": records, "columns": cols}
        finally:
            conn.close()

    # Tool: list tables
    def list_tables(self):
        if not self.db_path:
            return []
        conn = sqlite3.connect(f'file:{self.db_path}?mode=ro', uri=True)
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
        rows = [r[0] for r in cur.fetchall()]
        conn.close()
        return rows

    # Tool: inspect schema for given tables
    def inspect_schema(self, tables: Optional[list] = None):
        if not self.db_path:
            return {}
        conn = sqlite3.connect(f'file:{self.db_path}?mode=ro', uri=True)
        cur = conn.cursor()
        if not tables:
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
            tables = [r[0] for r in cur.fetchall()]
        schema = {}
        for t in tables:
            cur.execute(f"PRAGMA table_info('{t}')")
            cols = cur.fetchall()
            schema[t] = [{"name": c[1], "type": c[2]} for c in cols]
        conn.close()
        return schema

    def answer_query(self, user_query: str, max_rows: int = 10, debug: bool = False) -> Dict[str, Any]:
        # ReAct sequence: list tables -> inspect schema -> generate SQL -> check -> execute -> summarize
        try:
            tables = self.list_tables()
            schema = self.inspect_schema()
            # refresh internal schema if empty
            if not self.schema:
                self.schema = {t: {"columns": schema.get(t, [])} for t in schema}

            sql = self.generate_sql(user_query)
            if debug:
                print(f"DEBUG: Generated SQL:\n{sql}")
            if not self.validate_sql(sql):
                if debug:
                    print(f"DEBUG: SQL validation failed")
                return {"error": "Generated SQL failed validation"}

            # execute and limit rows for final output
            res = self.execute_sql(sql, limit=max_rows)
            # prepare natural language response
            rows = res.get("rows", [])
            cols = res.get("columns", [])
            if not rows:
                answer = "No results found."
            else:
                # create a concise summary and a small table
                answer = f"Returned {len(rows)} rows.\n"
                # build a small textual table
                sample_rows = rows[:max_rows]
                # format rows as short bullets
                bullets = []
                for r in sample_rows:
                    # include only up to 3 columns for brevity
                    keys = list(r.keys())[:3]
                    vals = [str(r[k]) for k in keys]
                    bullets.append("; ".join([f"{k}: {v}" for k, v in zip(keys, vals)]))
                answer += "\n".join([f"- {b}" for b in bullets])

            out = {"answer": answer, "rows": rows, "columns": cols}
            if debug:
                out["sql"] = sql
            return out
        except Exception as e:
            return {"error": f"Exception: {str(e)}"}

    def explain_results(self, rows: list) -> str:
        # Simple explanation: counts and example row
        if not rows:
            return "No rows returned."
        return f"Returned {len(rows)} rows. Example: {rows[0]}"
