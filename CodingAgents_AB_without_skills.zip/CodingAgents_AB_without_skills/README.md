# CrewAI Text-to-SQL Agent (Prototype)

This repository contains a prototype Text→SQL agent that:

- Discovers and extracts a SQLite schema (read-only).
- Uses OpenAI to translate natural language to SQL.
- Validates SQL to ensure only safe, read-only `SELECT` queries run (via `sqlglot`).
- Executes queries against a local SQLite DB in read-only mode and returns tabular results.

Quick start

1. Create a virtual environment and install dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Create a `.env` file (or set `OPENAI_API_KEY` in your environment). Use `.env.example` as a template.

3. Extract schema from the DB (this reads `problem_statement_task/banking_insights.db`):

```powershell
python scripts\extract_schema.py --db problem_statement_task\banking_insights.db --out artifacts\schema.json
```

4. Run a quick query via CLI:

```powershell
python bin\run_agent.py --query "Top 5 merchants by debit spend in July 2025"
```

5. Run the API server:

```powershell
uvicorn service.app:app --reload
```

Notes
- This project expects `OPENAI_API_KEY` to be available via environment variables (no Azure endpoints). Put it in `.env` or export it.
- The agent enforces read-only SQL using AST checks; it will reject non-SELECT statements.

Next steps
- Provide extracted `artifacts/schema.json` (run the script above) and PDF text extracts so prompts can be grounded with exact table/column names.
