import os
from agent.core import TextToSqlAgent


def test_validate_rejects_non_select():
    agent = TextToSqlAgent(db_path=None)
    bad = "DROP TABLE users;"
    assert not agent.validate_sql(bad)


def test_validate_accepts_simple_select():
    agent = TextToSqlAgent(db_path=None)
    good = "SELECT 1 as one"
    assert agent.validate_sql(good)
