from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv
import os

from agent.core import TextToSqlAgent

load_dotenv()

app = FastAPI()

agent = TextToSqlAgent(db_path=os.environ.get("DB_PATH", "problem_statement_task/banking_insights.db"), schema_path="artifacts/schema.json")


class QueryRequest(BaseModel):
    query: str
    debug: bool = False


@app.post("/query")
def query(req: QueryRequest):
    out = agent.answer_query(req.query, max_rows=10)
    if out.get("error"):
        raise HTTPException(status_code=400, detail=out.get("error"))

    # by default do not expose SQL; include only answer and small table
    result = {"answer": out.get("answer"), "rows": out.get("rows"), "columns": out.get("columns")}
    if req.debug:
        result["sql"] = out.get("sql")
    return result
